from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

# Load image
image_path = r"C:\Users\LENOVO\OneDrive\Documents\colourdraw.jpeg"
img = Image.open(image_path)

# Convert to RGB
img_rgb = img.convert("RGB")
rgb_np = np.array(img_rgb)

# Split color channels 
red = rgb_np[:, :, 0]
green = rgb_np[:, :, 1]
blue = rgb_np[:, :, 2]

# Display each color channel
plt.figure(figsize=(12,4))

plt.subplot(1,3,1)
plt.imshow(red, cmap='Reds')
plt.title("Red Channel")
plt.axis('off')

plt.subplot(1,3,2)
plt.imshow(green, cmap='Greens')
plt.title("Green Channel")
plt.axis('off')

plt.subplot(1,3,3)
plt.imshow(blue, cmap='Blues')
plt.title("Blue Channel")
plt.axis('off')

# Convert to Grayscale
gray = img_rgb.convert("L")
gray_np = np.array(gray)

# ---------- MANUAL OTSU THRESHOLDING ----------
hist, bins = np.histogram(gray_np.flatten(), 256, [0, 256])

total_pixels = gray_np.size
current_max = 0
threshold = 0
sum_total = np.dot(np.arange(256), hist)
sum_bg = 0
weight_bg = 0

for i in range(256):
    weight_bg += hist[i]
    if weight_bg == 0:
        continue
    
    weight_fg = total_pixels - weight_bg
    if weight_fg == 0:
        break

    sum_bg += i * hist[i]
    mean_bg = sum_bg / weight_bg
    mean_fg = (sum_total - sum_bg) / weight_fg

    between_var = weight_bg * weight_fg * (mean_bg - mean_fg) ** 2

    if between_var > current_max:
        current_max = between_var
        threshold = i

# Apply Otsu Threshold
otsu = gray_np > threshold
otsu = (otsu * 255).astype(np.uint8)

# Inversion
inverted = 255 - otsu

# ---------- DISPLAY ----------
plt.figure()
plt.title("Original RGB")
plt.imshow(img_rgb)
plt.axis("off")

plt.figure()
plt.title("Grayscale")
plt.imshow(gray_np, cmap="gray")
plt.axis("off")

plt.figure()
plt.title("Otsu Threshold")
plt.imshow(otsu, cmap="gray")
plt.axis("off")

plt.figure()
plt.title("Inverted Image")
plt.imshow(inverted, cmap="gray")
plt.axis("off")

plt.show()

